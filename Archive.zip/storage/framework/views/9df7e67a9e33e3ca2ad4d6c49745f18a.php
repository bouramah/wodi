

<img src="<?php echo e(asset('images/logo.png')); ?>" alt="WODI TRANSFER" style="height: 100px; width: auto; margin-top: 30px;">
<?php /**PATH /Users/ibrahimadoutyoulare/Documents/Code Perso/wodi/resources/views/components/application-logo.blade.php ENDPATH**/ ?>