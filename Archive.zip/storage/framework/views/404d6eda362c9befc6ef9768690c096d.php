<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Détails du dépôt')); ?>

            </h2>
            <div>
                <a href="<?php echo e(route('deposits.index')); ?>"
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    <?php echo e(__('Retour')); ?>

                </a>
                <?php if($deposit->remaining_amount > 0): ?>
                    <a href="<?php echo e(route('deposits.add-payment', $deposit)); ?>"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2">
                        <?php echo e(__('Ajouter paiement')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('deposits.edit', $deposit)); ?>"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded ml-2">
                    <?php echo e(__('Modifier')); ?>

                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php if(session('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                            role="alert">
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <!-- Informations sur le dépôt -->
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 border-b pb-2">
                                <?php echo e(__('Informations du dépôt')); ?>

                            </h3>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Client')); ?></p>
                                    <p class="text-base"><?php echo e($deposit->depositor->first_name); ?> <?php echo e($deposit->depositor->last_name); ?></p>
                                    <p class="text-sm text-gray-500"><?php echo e($deposit->depositor->phone_number); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Agent')); ?></p>
                                    <p class="text-base"><?php echo e($deposit->agent->first_name); ?> <?php echo e($deposit->agent->last_name); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Montant initial')); ?></p>
                                    <p class="text-base font-bold"><?php echo e(number_format($deposit->amount, 2, ',', ' ')); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Date de dépôt')); ?></p>
                                    <p class="text-base"><?php echo e($deposit->deposit_date->format('d/m/Y')); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Montant restant')); ?></p>
                                    <p class="text-base font-bold <?php echo e($deposit->remaining_amount > 0 ? 'text-green-600' : 'text-gray-700'); ?>">
                                        <?php echo e(number_format($deposit->remaining_amount, 2, ',', ' ')); ?>

                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-500"><?php echo e(__('Montant utilisé')); ?></p>
                                    <p class="text-base font-bold text-blue-600">
                                        <?php echo e(number_format($deposit->amount - $deposit->remaining_amount, 2, ',', ' ')); ?>

                                        <span class="text-sm font-normal text-gray-500">
                                            (<?php echo e(number_format(($deposit->amount - $deposit->remaining_amount) / $deposit->amount * 100, 0)); ?>%)
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Graphique ou statistiques -->
                        <div class="bg-gray-50 p-6 rounded-lg shadow">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 border-b pb-2">
                                <?php echo e(__('Progression')); ?>

                            </h3>
                            <div class="mb-6">
                                <div class="relative pt-1">
                                    <div class="flex mb-2 items-center justify-between">
                                        <div>
                                            <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                                                <?php echo e(__('Utilisation du dépôt')); ?>

                                            </span>
                                        </div>
                                        <div class="text-right">
                                            <span class="text-xs font-semibold inline-block text-blue-600">
                                                <?php echo e(number_format(($deposit->amount - $deposit->remaining_amount) / $deposit->amount * 100, 0)); ?>%
                                            </span>
                                        </div>
                                    </div>
                                    <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                                        <div style="width: <?php echo e(($deposit->amount - $deposit->remaining_amount) / $deposit->amount * 100); ?>%"
                                            class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <p class="text-sm text-gray-500 mb-2"><?php echo e(__('Résumé des paiements')); ?></p>
                                <div class="grid grid-cols-2 gap-4">
                                    <div class="bg-indigo-100 p-3 rounded-lg">
                                        <p class="text-xs font-medium text-indigo-800"><?php echo e(__('Nombre de paiements')); ?></p>
                                        <p class="text-xl font-bold text-indigo-800"><?php echo e($deposit->payments->count()); ?></p>
                                    </div>
                                    <div class="bg-green-100 p-3 rounded-lg">
                                        <p class="text-xs font-medium text-green-800"><?php echo e(__('Dernier paiement')); ?></p>
                                        <p class="text-xl font-bold text-green-800">
                                            <?php if($deposit->payments->isNotEmpty()): ?>
                                                <?php echo e($deposit->payments->sortByDesc('payment_date')->first()->payment_date->format('d/m/Y')); ?>

                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Liste des paiements -->
                    <div class="mt-8">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">
                            <?php echo e(__('Historique des paiements')); ?>

                        </h3>

                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col"
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Date')); ?>

                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Montant payé')); ?>

                                        </th>
                                        <th scope="col"
                                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Solde après paiement')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__empty_1 = true; $__currentLoopData = $deposit->payments->sortByDesc('payment_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e($payment->payment_date->format('d/m/Y')); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e(number_format($payment->amount_paid, 2, ',', ' ')); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php
                                                        $runningTotal = $deposit->amount;
                                                        foreach ($deposit->payments->sortBy('payment_date') as $p) {
                                                            $runningTotal -= $p->amount_paid;
                                                            if ($p->id === $payment->id) {
                                                                break;
                                                            }
                                                        }
                                                    ?>
                                                    <?php echo e(number_format($runningTotal, 2, ',', ' ')); ?>

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3" class="px-6 py-4 text-center text-gray-500">
                                                <?php echo e(__('Aucun paiement trouvé.')); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/ibrahimadoutyoulare/Documents/Code Perso/wodi/resources/views/deposits/show.blade.php ENDPATH**/ ?>