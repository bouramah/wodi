<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo e(__('Liste des transferts')); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e(__('Liste des transferts')); ?></h1>
        <?php if(request('filter_type') === 'date_range'): ?>
            <p><?php echo e(__('Période')); ?>: <?php echo e(request('start_date')); ?> - <?php echo e(request('end_date')); ?></p>
        <?php elseif(request('filter_type') === 'month'): ?>
            <p><?php echo e(__('Mois')); ?>: <?php echo e(request('month')); ?></p>
        <?php endif; ?>
    </div>

    <table>
        <thead>
            <tr>
                <th><?php echo e(__('Code')); ?></th>
                <th><?php echo e(__('Expéditeur')); ?></th>
                <th><?php echo e(__('Destinataire')); ?></th>
                <th><?php echo e(__('Montant')); ?></th>
                <th><?php echo e(__('Statut')); ?></th>
                <th><?php echo e(__('Date')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transfer->code); ?></td>
                    <td><?php echo e($transfer->sender->first_name); ?> <?php echo e($transfer->sender->last_name); ?></td>
                    <td><?php echo e($transfer->receiver->first_name); ?> <?php echo e($transfer->receiver->last_name); ?></td>
                    <td><?php echo e(number_format($transfer->amount, 2)); ?> <?php echo e($transfer->currency->code); ?></td>
                    <td><?php echo e(__('transfers.status.' . $transfer->status)); ?></td>
                    <td><?php echo e($transfer->transfer_date->format('d/m/Y H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        <p><?php echo e(__('Généré le')); ?>: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
    </div>
</body>
</html>
<?php /**PATH /Users/ibrahimadoutyoulare/Documents/Code Perso/wodi/resources/views/transfers/pdf.blade.php ENDPATH**/ ?>