<?php

return [
    'status' => [
        'pending' => 'En attente',
        'paid' => 'Payé',
        'cancelled' => 'Annulé',
    ],
];
